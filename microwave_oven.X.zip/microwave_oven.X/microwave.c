/*
 * File:   microwave.c
 * Author: padma
 *
 * Created on 4 April, 2025, 3:35 PM
 */


#include <xc.h>
#include "main.h"

//global variables
unsigned char min,sec,pre_ht_time;
extern unsigned char operational_flag;

//power on screen
void power_on_screen(void)
{
    for(unsigned int i=0;i<16;i++)
    {
        clcd_putch(0xFF,LINE1(i));
    }
    clcd_print("Power on",LINE2(1));
    clcd_print("Microwave oven",LINE3(0));
    for(unsigned int j=0;j<16;j++)
    {
        clcd_putch(0xFF,LINE4(j));
    }
    __delay_ms(5000);
}

//clear screen function
void clear_screen(void)
{
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE);
    __delay_us(500);
}

//display menu function
void display_menu(void)
{
    clcd_print("1.MICRO ",LINE1(0));
    clcd_print("2.GRILL",LINE2(0));
    clcd_print("3.CONVECTION",LINE3(0));
    clcd_print("4.START",LINE4(0));
}

//set time function
void set_time(unsigned char key,unsigned char reset_flag)
{
    static unsigned char blink_pos=0;
    static unsigned char key_count=0;
    if(reset_flag==RESET_MODE)//reset the time setting if flag is active
    {
        blink_pos=0;
        key_count=0;
        key=ALL_RELEASED;
        min=0;
        sec=0;
        reset_flag = RESET_NOTHING;
    }
      //set time    
      //for(unsigned char wait =50;wait--;);   
      clcd_print("SET TIME (MM:SS)", LINE1(0));
      clcd_print("TIME-", LINE2(0));
      clcd_print("*:CLEAR  #:ENTER", LINE4(0));
      if(key!='*' && key!='#' && key!=ALL_RELEASED)
      {
        key_count++;
        if(key_count <=2){
            sec= sec*10+key;
            blink_pos=0;
        }
        else if(key_count <=4){
            min=min*10+key;
            blink_pos=1;
        }
       }
      //if key=='*',it clear the current time entry
        else if(key =='*')
        {
        if(blink_pos)
        {
            min=0;
            key_count=2;
        }
        else
        {
            sec=0;
            key_count=0;
        }
        }
      //if key=='#',it microwave starts
        else if(key=='#')
        {
            FAN=1;
            TMR2ON=1;
            operational_flag=DISPLAY_TIME;
            clear_screen();
        }
      
      //handling the cursor blinking
       if (blink_pos ==0)
       {
       clcd_putch(' ', LINE2(9));
       clcd_putch(' ', LINE2(10));
       }
       else
       {
       clcd_putch(' ', LINE2(6));
       clcd_putch(' ', LINE2(7));
       }
      
      //update the time display
      for(unsigned char wait=50;wait--;);
      clcd_putch(sec/10+'0', LINE2(9));
      clcd_putch(sec%10+'0', LINE2(10));
      clcd_putch( ':', LINE2(8));
      clcd_putch(min/10+'0', LINE2(6));
      clcd_putch(min%10+'0', LINE2(7));
}

void sound_buzzer(void)
{
    // Make sure buzzer pin is configured as output
    BUZZER_DDR= 0;
    
    // Sound the buzzer with multiple beeps that are long enough to hear
    for(unsigned char i = 0; i < 200; i++)
    {
        BUZZER= 1;
        __delay_ms(500);  // Longer on time - 500ms
        BUZZER= 0;
        __delay_ms(200);  // Short pause between beeps
    }
    __delay_ms(500);
}
    
    
    //time display function
    void time_display(void)
    {
        //display remaining time and operations
        clcd_print("TIME= ", LINE1(1));
        clcd_putch(min/10+'0', LINE1(9));
        clcd_putch(min%10+'0', LINE1(10));
        clcd_putch( ':', LINE1(11));
        clcd_putch(sec/10+'0', LINE1(12));
        clcd_putch(sec%10+'0', LINE1(13));
        clcd_print("4.Start/Resume ",LINE2(1));
        clcd_print("5.Pause ",LINE3(1));
        clcd_print("6.Stop ",LINE4(1));
        
        //stop the microwave oven when time reaches 0:00
        if(min==0&&sec==0)
        {
            TMR2ON=0;
            FAN=0;
            clear_screen();
            clcd_print("TIME UP!",LINE2(4));
            clcd_print("FOOD READY",LINE3(2));
            // Call the buzzer function
            sound_buzzer();
            clear_screen();
            operational_flag=MENU_SCREEN;
        }
    }
//set temperature function
void set_temp(unsigned char key, unsigned char reset_flag)
{
    static unsigned char key_count;
    static unsigned int temp;
    
    if(reset_flag == RESET_MODE)
    {
        temp = 0;
        key_count = 0;
        key = ALL_RELEASED;
    }
    
    // Display
    clcd_print("SET TEMP. (*C)", LINE1(0));
    clcd_print("TEMP : ", LINE2(0));
    clcd_print("*:CLEAR  #:ENTER", LINE4(0));
    clcd_putch(' ', LINE2(8));
    clcd_putch(' ', LINE2(9));
    clcd_putch(' ', LINE2(10));
    
    for(unsigned char wait = 50; wait--; );
    clcd_putch((temp/100 + '0'), LINE2(8));
    clcd_putch(((temp/10)%10 + '0'), LINE2(9));
    clcd_putch((temp%10 + '0'), LINE2(10));
    
    // User input temperature in celsius
    if(key != '*' && key != '#' && key != ALL_RELEASED)
    {
        if(key_count < 3)
        {
            temp = temp * 10 + key;
            key_count++;
        }
    }
    
    if(key == '*')
    {
        temp = 0;
        key_count = 0;
    }
    
    if(key == '#')
    {
        if(temp > 180)
        {
            temp = 180;
        }
        
        clear_screen();
        clcd_print("Pre-Heating", LINE1(2));
        clcd_print("Time-Rem.= ", LINE3(0));
        clcd_print("sec", LINE3(13));
        
        // Set pre-heating time and start timer
        pre_ht_time = 60;
        TMR2ON = 1;
        
        // This is the problematic loop - fixed
        while(pre_ht_time > 0)
        {
            // Update the display of remaining time
            clcd_putch((pre_ht_time/10)/10 + '0', LINE3(10));
            clcd_putch((pre_ht_time/10)%10 + '0', LINE3(11));
            clcd_putch((pre_ht_time%10) + '0', LINE3(12));
            
            // Add delay to allow timer interrupt to decrement pre_ht_time
            __delay_ms(100);
        }
        
        TMR2ON = 0;
        clear_screen();
        operational_flag = MICRO_MODE;
    }
} 
     //start microwave for 30seconds 
  void heat_food(void)
    {
    sec=30;
    min=0;
    FAN=1;
    TMR2ON=1;
    operational_flag = DISPLAY_TIME;
    }




