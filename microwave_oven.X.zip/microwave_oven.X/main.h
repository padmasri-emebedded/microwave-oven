#ifndef MAIN_H
#define MAIN_H

#include "clcd.h"
#include "matrix_keypad.h"
#include "timers.h"
#include  "microwave.h"

#define POWER_ON_SCREEN   0x01
#define MENU_SCREEN       0x02

#define MICRO_MODE        0x11
#define GRILL_MODE        0x12
#define CONVECTION_MODE   0x13
#define START_MODE        0x14
#define DISPLAY_TIME      0x15
#define START             0x16
#define STOP              0x17
#define PAUSE             0x18

#define RESET_MODE        0x20
#define RESET_NOTHING     0x21

#define FAN_DDR           TRISC2
#define FAN               RC2
#define BUZZER_DDR        TRISC3
#define BUZZER            RC3

#endif

