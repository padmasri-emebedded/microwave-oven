#include <xc.h>

void init_timer2(void)
{
    // Stop Timer2 before configuration
    TMR2ON = 0;
    
    // Clear Timer2 value
    TMR2 = 0;
    
    // Setting prescaler (1:16)
    T2CKPS1 = 1;
    T2CKPS0 = 1;
    
    // Setting postscaler (1:1)
    TOUTPS3 = 0;
    TOUTPS2 = 0;
    TOUTPS1 = 0;
    TOUTPS0 = 0;
    
    // Load PR2 register with the value needed for timing
    PR2 = 125; 
    
    // Clear the interrupt flag
    TMR2IF = 0;
    
    // Enable Timer2 interrupt
    TMR2IE = 1;
    
}