#include <xc.h>
#include "main.h"

extern unsigned char pre_ht_time;
extern unsigned char min, sec;
unsigned int count;

void __interrupt() isr(void)
{
    if(TMR2IF)
    {
        if(++count == 1000) // For second
        {
            count = 0;
            
            // Handle countdown logic
            if(sec > 0)
            {
                sec--;
            }
            else if(min > 0)
            {
                min--;
                sec = 59; // Set to 59, not 60
            }
            
            // Handle pre-heating time separately
            if(pre_ht_time > 0)
            {
                pre_ht_time--;
            }
        }
        
        TMR2IF = 0; // Clear interrupt flag
    }
}