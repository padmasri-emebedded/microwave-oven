/*
 * File:   main.c
 * Author: padma
 *
 * Created on 4 April, 2025, 1:23 PM
 */


#include <xc.h>
#include "main.h"
#pragma config WDTE=OFF
 
//global variable declaration
unsigned char operational_flag=POWER_ON_SCREEN;
unsigned char  reset_flag=RESET_NOTHING;
extern unsigned char min,sec;

//initialization of 
void init_config(void)
{
    init_clcd();//initialization of clcd
    init_matrix_keypad();//initialization of matrix keypad
    init_timer2();//initialization of timer 2
    FAN_DDR=0;//fan data direct register as output
    FAN=0;//turn fan off
    BUZZER_DDR=0;//CONFIG BUZZER PINS as output
    BUZZER=0;
    GIE=1;//global interrput enable
    PEIE=1;//enable peripheral interruppt
}
void main(void)
{
    unsigned char key;
    unsigned char start_mode=0;//flag which check the cooking mode is started
    init_config();
    while(1)
    {
        key=read_matrix_keypad(STATE);
        
        if(operational_flag==MENU_SCREEN)//hadeling menu screen
        {
            if(key==1)//micro mode
            {
                clear_screen();
                operational_flag=MICRO_MODE;
                start_mode=0;
                clcd_print("POWER=900W",LINE2(0));
                __delay_ms(3000);
                clear_screen();
                reset_flag=RESET_MODE;
            }
            else if(key==2)//grill mode
            {
                operational_flag=GRILL_MODE;
                clear_screen();
                start_mode=0;
                reset_flag=RESET_MODE;
            }
            else if(key==3)//convection mode
            {
                operational_flag=CONVECTION_MODE;
                clear_screen();
                start_mode=0;
                reset_flag=RESET_MODE;
            }
            else if(key==4)//start mode
            {
                operational_flag=START_MODE;
                clear_screen();
                start_mode=1;
                reset_flag=RESET_MODE;
            }
        }
        //handeling pause/stop
        if(operational_flag==DISPLAY_TIME)
        {
            if(key==4)//add 30sec of the timer
            {
                if(start_mode)
                {
                    sec=sec+30;
                    if(sec>59)
                    {
                        min++;
                        sec=sec-60;                       
                    }
                }
            }
            else if(key==5)//pause the microwave
            {
                operational_flag=PAUSE;
            }
            else if(key==6)//stop the microwave
            {
                operational_flag=STOP;
            }
        }
        else if(operational_flag==PAUSE)
        {
            if(key==4)//resume cooking
            {
                FAN=1;
                TMR2ON=1;
                operational_flag=DISPLAY_TIME;
            }
        }
        
       switch(operational_flag)
       {
           case POWER_ON_SCREEN://diaply power on screen
               power_on_screen();
               operational_flag=MENU_SCREEN;
               clear_screen();
               break;
               
           case MENU_SCREEN://diaplay menu screen
               display_menu();
               break;
               
           case MICRO_MODE://display micro mode
               set_time(key,reset_flag);
               break;
               
           case DISPLAY_TIME://update the display with time
               time_display();
               break;
            
           case PAUSE://stop the timer and fan when paused
               FAN=0;
               TMR2ON=0;
               break;
               
           case STOP://stop everuthing and return to menu screen
               FAN=0;
               TMR2ON=0;
               clear_screen();
               operational_flag=MENU_SCREEN;
               break;
               
           case GRILL_MODE://grill mode-set time
               set_time(key,reset_flag);
               break;
               
           case CONVECTION_MODE://convection mode -set temperature
               set_temp(key,reset_flag);
               break;
               
           case START_MODE:
               heat_food();//start the cooking process
               
       }
       reset_flag=RESET_NOTHING;
    }
    
}

